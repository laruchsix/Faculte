package pen;

public class Pen {

    private Cartridge cartridge;
    private final Cap CAP;

    public Pen() {
    }

    public Pen(String m) {
    }

    //removes the cartridge
    public void freeCart() {
    }

    public void changeCartridge(Cartridge c) {
    }

    public boolean write(String text) {
    }

    Cartridge getCartridge() {
    }

}
