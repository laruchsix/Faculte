package pen;

public class Cap {

    public final String BRAND;
    public static final String DEFAULT_BRAND = "bic";

    public Cap(String m) {
    }

    public Cap() {
    }
}
